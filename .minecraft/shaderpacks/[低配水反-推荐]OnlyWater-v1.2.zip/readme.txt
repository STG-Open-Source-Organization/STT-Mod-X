OnlyWater Shader byMrY: youtube.com/hdjellybeanlp
Thanks to Edi ZockLP for cleaning up my code!

THANK YOU FOR DOWNLOADING MY SHADERPACK!

If you have questions or bugs you want to report, please write on my post at minecraftforum.net or on YouTube :)
Have fun!