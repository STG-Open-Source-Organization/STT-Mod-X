# Wisdom-Shaders
A Minecraft shaderspack. Offers high performance with high quality at the same time.

# This shaderspack REQUIRE a PBR texturepack
Unless you can't find one PBR texturepack..
