# Wisdom-Shaders
A Minecraft shaderspack. Offers high performance with high quality at the same time.

# Official website
https://qionouu.cn/
